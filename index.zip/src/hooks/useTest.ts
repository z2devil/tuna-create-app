import { useState } from 'react';

const useTest = () => {
  const [testMessage] = useState('test message');
  return { testMessage };
};

export default useTest;
