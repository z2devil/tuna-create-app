import RouteConfig from './route';

export default {
  HOME: new RouteConfig({
    path: '/',
    name: 'Home',
  }),
  Application: new RouteConfig({
    path: '/app',
    name: 'Application',
  }),
  FormDesign: new RouteConfig({
    path: '/app/formdesign',
    name: 'FormDesign',
  }),
  ProcessDesign: new RouteConfig({
    path: '/app/processdesign',
    name: 'ProcessDesign',
  }),
};
