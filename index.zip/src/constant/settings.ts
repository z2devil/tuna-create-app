export default {
  /**
   * 标题
   */
  title: 'zone 前端模板',

  /**
   * 作者
   */
  author: 'z2devil',

  /**
   * 请求相关
   */
  request: {
    // 后端接口地址
    baseURL: 'http://localhost:3000',

    // 请求超时时间: 30000,
    timeout: 30000,

    // 请求体数据类型
    contentType: 'application/json',

    // 请求头名称
    header: 'authorization',

    // token 过期时间
    tokenExpires: 30,
  },
};
