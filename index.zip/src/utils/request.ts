import axios, { AxiosRequestHeaders } from 'axios';
import settings from '../constant/settings';
import auth from './auth';

const service = axios.create({
  baseURL: settings.request.baseURL,
  timeout: settings.request.timeout,
});

service.interceptors.request.use(
  config => {
    if (auth.isAuthenticated()) {
      config.headers = {
        ...config.headers,
        // [settings.request.header]: auth.getToken(),
        // ['Content-Type']: settings.request.contentType,
      } as AxiosRequestHeaders;
    }
    return config;
  },
  error => {
    return Promise.reject(error);
  }
);

service.interceptors.response.use(
  response => {
    return response.data;
  },
  error => {
    return Promise.reject(error);
  }
);

export default service;
